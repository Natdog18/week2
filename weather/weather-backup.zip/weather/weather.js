var cityName;

 
function weatherAtLocation(lat, log) {


    var darkSky = "https://api.darksky.net/forecast/b908e5cb0e40855083f622994f9ec836/" + lat + "," + log;
    var currentWeather={
      url:darkSky,
      dataType:"jsonp",
      success: info_Complete

    };


    $.ajax(currentWeather);

    
}

function info_Complete(weatherInfo){
console.log(result.timezone + ".");
var weatherInfo={
  time:(currently.time),
  lrgTemp:(currently.Temperature),
  condition:(currently.summary),
  minTemp:(daily.data[0].temperatureMin),
  rainProb:(daily.data[0].precipProbability),
  maxTemperature:(daily.data[0].temperatureMax),
  icon:(currently.icon),
  minText:("Min"),
  rainChance:("Rain Chance"),
  maxText:("Max")


};
console.log(weatherInfo);
createCard(weatherInfo);


}





  function getLocation (zipcode) {
      var request= {
      url:"https://maps.googleapis.com/maps/api/geocode/json?address=" + zipcode + "&key=AIzaSyBn7kAW5YxaUR2GPcgaQedUMMODW4gcjgA",
      success:getLocation_done

    };
    $.ajax(request);
  }
    function getLocation_done(result){
   var lat  =  request[0].geometry.location.lat;
   var long = request[0].geometry.location.lng;
   cityName = request.results[0].address_components[1].short_name + "," +
              request.results[0].address_components[3].short_name;
   

weatherAtLocation();
    }


      
   
  
 
   function textBoxval (){
    var zipcode = $("location").val();
    getLocation("","",zipcode);
  
  }
$(function (){
  $("more").on("click", textBoxval);
 });
   



function makecard(weatherInfo){
  var data=$("#newTemplate").html();
    data =  data.replace("**date/time**", weatherInfo.time);
    data =  data.replace("**lrgDrgree**", weatherInfo.lrgTemp);
    data =  data.replace("**cond**", weatherInfo.condition);
    data =  data.replace("**minTemp**", weatherInfo.minTemp);
    data =  data-replace("**rain%**", weatherInfo.rainProb);
    date =  data.replace("**maxTemp**",weatherInfo.maxTemperature);
    data =  data.replace("**Min**", weatherInfo.time);
    data =  data.replace("**rainChance**", weatherInfo.time);
    data =  data.replace("**Max**", weatherInfo.time);
    data =  data.replace("**class**",weatherInfo.icon);
    return data;

}

function createCard(weatherInfo){
  var html= makeCard(weatherInfo);
  $("#newTemplate").append(html);
}


